/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.tetrisgame;

/**
 *
 * @author babou
 */
public class TetrisGame {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
